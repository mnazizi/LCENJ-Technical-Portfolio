#include <stdbool.h>
#include "driver/gpio.h"
#include "esp_err.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#define PMOS_NPN_DRIVER_GPIO GPIO_NUM_19

/*
 * GPIO=1 -> NPN روشن -> Gate ماسفت پایین -> PMOS روشن
 * GPIO=0 -> NPN خاموش -> Pull-up گیت را به Source می‌برد -> PMOS خاموش
 */
static void load_power_set(bool enabled)
{
    ESP_ERROR_CHECK(gpio_set_level(PMOS_NPN_DRIVER_GPIO, enabled ? 1 : 0));
}

void app_main(void)
{
    const gpio_config_t output = {
        .pin_bit_mask = 1ULL << PMOS_NPN_DRIVER_GPIO,
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    ESP_ERROR_CHECK(gpio_config(&output));

    load_power_set(false);

    while (1) {
        load_power_set(true);
        vTaskDelay(pdMS_TO_TICKS(3000));

        load_power_set(false);
        vTaskDelay(pdMS_TO_TICKS(3000));
    }
}
