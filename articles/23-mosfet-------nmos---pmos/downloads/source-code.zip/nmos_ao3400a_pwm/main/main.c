#include <stdint.h>
#include "driver/ledc.h"
#include "esp_err.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#define MOSFET_GATE_GPIO      18
#define PWM_MODE              LEDC_LOW_SPEED_MODE
#define PWM_TIMER             LEDC_TIMER_0
#define PWM_CHANNEL           LEDC_CHANNEL_0
#define PWM_FREQUENCY_HZ      5000
#define PWM_RESOLUTION        LEDC_TIMER_10_BIT
#define PWM_MAX_DUTY          1023

static void pwm_set_percent(uint32_t percent)
{
    if (percent > 100) {
        percent = 100;
    }

    const uint32_t duty = (PWM_MAX_DUTY * percent) / 100;
    ESP_ERROR_CHECK(ledc_set_duty(PWM_MODE, PWM_CHANNEL, duty));
    ESP_ERROR_CHECK(ledc_update_duty(PWM_MODE, PWM_CHANNEL));
}

void app_main(void)
{
    const ledc_timer_config_t timer = {
        .speed_mode = PWM_MODE,
        .duty_resolution = PWM_RESOLUTION,
        .timer_num = PWM_TIMER,
        .freq_hz = PWM_FREQUENCY_HZ,
        .clk_cfg = LEDC_AUTO_CLK,
    };
    ESP_ERROR_CHECK(ledc_timer_config(&timer));

    const ledc_channel_config_t channel = {
        .gpio_num = MOSFET_GATE_GPIO,
        .speed_mode = PWM_MODE,
        .channel = PWM_CHANNEL,
        .intr_type = LEDC_INTR_DISABLE,
        .timer_sel = PWM_TIMER,
        .duty = 0,
        .hpoint = 0,
    };
    ESP_ERROR_CHECK(ledc_channel_config(&channel));

    const uint32_t test_levels[] = {0, 25, 50, 75, 100};

    while (1) {
        for (size_t i = 0; i < sizeof(test_levels) / sizeof(test_levels[0]); ++i) {
            pwm_set_percent(test_levels[i]);
            vTaskDelay(pdMS_TO_TICKS(2500));
        }
    }
}
