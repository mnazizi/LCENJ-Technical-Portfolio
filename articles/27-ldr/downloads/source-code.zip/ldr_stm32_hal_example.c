#include "main.h"
#include <stdio.h>

extern ADC_HandleTypeDef hadc1;
extern UART_HandleTypeDef huart2;

static uint32_t ldr_read_adc(void)
{
    HAL_ADC_Start(&hadc1);
    HAL_ADC_PollForConversion(&hadc1, 10);
    uint32_t value = HAL_ADC_GetValue(&hadc1);
    HAL_ADC_Stop(&hadc1);
    return value;
}

static void ldr_send_uart(uint32_t adc)
{
    char msg[64];
    int len = snprintf(msg, sizeof(msg), "LDR ADC = %lu\r\n", adc);
    HAL_UART_Transmit(&huart2, (uint8_t*)msg, len, 100);
}

int main(void)
{
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_ADC1_Init();
    MX_USART2_UART_Init();

    while (1)
    {
        uint32_t adc = ldr_read_adc();

        /* Threshold example: in darkness the divider output changes and
           the LED status is switched. Threshold must be calibrated in practice. */
        if (adc > 2500)
        {
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);
        }
        else
        {
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
        }

        ldr_send_uart(adc);
        HAL_Delay(100);
    }
}
