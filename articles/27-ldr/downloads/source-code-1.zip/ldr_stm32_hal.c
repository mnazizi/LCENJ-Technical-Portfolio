#include "main.h"
#include <stdint.h>
#include <stdio.h>

extern ADC_HandleTypeDef hadc1;
extern UART_HandleTypeDef huart2;

#define LDR_SAMPLES 16U

static uint32_t ldr_read_adc_average(void)
{
    uint32_t sum = 0;

    for (uint32_t i = 0; i < LDR_SAMPLES; ++i)
    {
        HAL_ADC_Start(&hadc1);
        if (HAL_ADC_PollForConversion(&hadc1, 20) == HAL_OK)
        {
            sum += HAL_ADC_GetValue(&hadc1);
        }
        HAL_ADC_Stop(&hadc1);
    }

    return sum / LDR_SAMPLES;
}

static void ldr_print(uint32_t adc)
{
    char line[64];
    int len = snprintf(line, sizeof(line), "LDR ADC = %lu\r\n", (unsigned long)adc);
    HAL_UART_Transmit(&huart2, (uint8_t *)line, (uint16_t)len, 100);
}

void ldr_example_task(void)
{
    const uint32_t threshold = 2500U;   /* Calibrate this value in the real setup. */
    uint32_t adc = ldr_read_adc_average();

    if (adc > threshold)
    {
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);
    }
    else
    {
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
    }

    ldr_print(adc);
}
