LDR + STM32 HAL example

Hardware example:
- LDR: GL5528 or equivalent
- R1: 10 kOhm, 1%
- VCC: 3.3 V
- VOUT -> PA0 / ADC1_IN0 (example)
- Optional C1: 100 nF from VOUT to GND

Important:
1. CubeMX must configure ADC1 and the selected ADC channel.
2. Increase ADC sampling time when divider source impedance is high.
3. Calibrate the threshold in the real light conditions.
4. LDR has no polarity and no digital protocol; it is a variable resistor.
