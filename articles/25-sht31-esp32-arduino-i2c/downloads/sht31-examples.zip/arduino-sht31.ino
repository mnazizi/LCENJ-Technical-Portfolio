#include <Wire.h>
#include <Adafruit_SHT31.h>

Adafruit_SHT31 sht31;

void setup() {
  Serial.begin(115200);
  Wire.begin();
  if (!sht31.begin(0x44)) {
    Serial.println("SHT31 not found. Check wiring and address.");
    while (true) delay(10);
  }
}

void loop() {
  const float temperature = sht31.readTemperature();
  const float humidity = sht31.readHumidity();
  if (!isnan(temperature) && !isnan(humidity)) {
    Serial.printf("T: %.2f C | RH: %.2f %%\n", temperature, humidity);
  } else {
    Serial.println("Read error");
  }
  delay(2000);
}
