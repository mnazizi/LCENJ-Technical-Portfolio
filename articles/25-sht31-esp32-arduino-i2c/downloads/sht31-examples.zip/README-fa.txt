نمونه‌کدهای مقاله جامع SHT31 در LCENJ

arduino-sht31.ino:
استفاده ساده از کتابخانه Adafruit SHT31 برای Arduino و ESP32.

esp32-sht31-raw.ino:
خواندن مستقیم با Wire، فرمان Single-shot و کنترل CRC-8.

i2c-scanner.ino:
پیدا کردن آدرس سنسور روی باس I2C؛ SHT31 معمولاً 0x44 یا 0x45 است.

مرجع فنی:
https://sensirion.com/media/documents/213E6A3B/63A5A569/Datasheet_SHT3x_DIS.pdf
