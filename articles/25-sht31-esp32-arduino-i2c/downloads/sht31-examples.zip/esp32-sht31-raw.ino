#include <Wire.h>

constexpr uint8_t SHT31_ADDRESS = 0x44;

uint8_t crc8(const uint8_t *data, size_t len) {
  uint8_t crc = 0xFF;
  for (size_t i = 0; i < len; ++i) {
    crc ^= data[i];
    for (uint8_t bit = 0; bit < 8; ++bit) {
      crc = (crc & 0x80) ? (crc << 1) ^ 0x31 : (crc << 1);
    }
  }
  return crc;
}

bool readSHT31(float &temperature, float &humidity) {
  Wire.beginTransmission(SHT31_ADDRESS);
  Wire.write(0x24);
  Wire.write(0x00);
  if (Wire.endTransmission() != 0) return false;
  delay(15);

  if (Wire.requestFrom(SHT31_ADDRESS, (uint8_t)6) != 6) return false;
  uint8_t data[6];
  for (uint8_t &byte : data) byte = Wire.read();
  if (crc8(data, 2) != data[2] || crc8(data + 3, 2) != data[5]) return false;

  const uint16_t rawT = (uint16_t(data[0]) << 8) | data[1];
  const uint16_t rawRH = (uint16_t(data[3]) << 8) | data[4];
  temperature = -45.0f + 175.0f * rawT / 65535.0f;
  humidity = 100.0f * rawRH / 65535.0f;
  return true;
}

void setup() {
  Serial.begin(115200);
  Wire.begin();
}

void loop() {
  float temperature, humidity;
  if (readSHT31(temperature, humidity)) {
    Serial.printf("T: %.2f C | RH: %.2f %%\n", temperature, humidity);
  } else {
    Serial.println("I2C or CRC error");
  }
  delay(2000);
}
